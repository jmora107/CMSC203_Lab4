package Lab4Launch;
/** 
*The purpose of this class is to model a television
*Julian Morales 2/20/2020
*/


public class Television {

final String MANUFACTURER; //brand of the television
final int SCREEN_SIZE; //what screen size this television has
boolean powerOn; //whether the power of the television is on
int channel; //in what channel the television is on
int volume; // what volume the television has


//This constructor assigns the parameters to their own fields
//It also initializes powerOn, volume, and channel

public Television (String MANUFACTURER, int SCREEN_SIZE){
	
	this.MANUFACTURER = MANUFACTURER;
	this.SCREEN_SIZE = SCREEN_SIZE;
	powerOn = false;
	volume = 20;
	channel = 2;
}

/**
 * Accessor methods, getVolume, getChannel, getManufacturer,
 * and getScreenSize return the value of the corresponding field
 * 
 */
public int getVolume () {
	
	return volume;
}

public int getChannel () {
	
	return channel;
}

public String getManufacturer () {
	
	return MANUFACTURER;
}

public int getScreenSize () {
	
	return SCREEN_SIZE;
}

/**
 * Mutator method setChannel accepts a value to be stored in
 * "channel"
 */

public void setChannel (int aChannel) {
	
	channel = aChannel;
}

/**
 * Mutator method power changes the state from true to false
 * or from false to true of "powerOn"
 */

public void power () {
	
	this.powerOn = !this.powerOn;
}

/**
 * Mutator methods increaseaVolume and decreaseVolume
 * increase or decrease the value of "volume" by 1
 */

public void increaseVolume () {
	
	volume += 1; 
}

public void decreaseVolume () {
	
	volume -= 1;
}
}

